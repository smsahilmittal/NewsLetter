package com.example.NewsLetter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsLetterApplicationTests {

	@Test
	void contextLoads() {
	}

}
