package com.example.NewsLetter.entities;

import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class Category {
  private String id;
  private String name;
}
