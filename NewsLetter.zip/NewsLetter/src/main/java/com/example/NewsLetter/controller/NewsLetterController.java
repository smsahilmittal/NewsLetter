package com.example.NewsLetter.controller;

import com.example.NewsLetter.entities.NewsLetter;
import com.example.NewsLetter.input.InputRequest;
import com.example.NewsLetter.input.ResponseOutput;
import com.example.NewsLetter.service.NewsLetterService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class NewsLetterController {

  @Autowired
  NewsLetterService newsLetterService;

  @PostMapping(value = "/newsLetter")
  public List<NewsLetter> getNewsLetter(@RequestBody final InputRequest inputRequest) {
    return newsLetterService.getNewsLetterByCategories(inputRequest);
  }

  @PostMapping(value = "/add/newsLetter")
  public void addNewsLetter(@RequestBody final NewsLetter newsLetter) {
    newsLetterService.addNewsLetter(newsLetter);
  }
}
