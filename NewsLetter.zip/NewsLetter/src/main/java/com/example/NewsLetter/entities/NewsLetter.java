package com.example.NewsLetter.entities;

import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
public class NewsLetter {
  private String id;
  private String categoryName;
  private String title;
  private String userId;
  private String price;
}
