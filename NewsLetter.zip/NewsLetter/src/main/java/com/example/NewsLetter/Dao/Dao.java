package com.example.NewsLetter.Dao;

import com.example.NewsLetter.entities.User;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface Dao <K,V>{
  List<V> getAll();
  Optional<V> getById(K key);
  void save(V entity);
}
