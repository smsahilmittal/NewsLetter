package com.example.NewsLetter.controller;

import com.example.NewsLetter.entities.User;
import com.example.NewsLetter.input.InputRequest;
import com.example.NewsLetter.input.ResponseOutput;
import com.example.NewsLetter.service.UserService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

  @Autowired
  UserService userService;

  @PostMapping(value = "/user/register")
  public ResponseOutput addUser(@RequestBody final InputRequest inputRequest) {
    return userService.addUser(inputRequest);
  }
  @PostMapping(value = "/user/all")
  public List<User> getAllUsers() {
    return userService.getAllUser();
  }
}
