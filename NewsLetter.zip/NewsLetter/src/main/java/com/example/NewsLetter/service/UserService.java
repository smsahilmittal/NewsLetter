package com.example.NewsLetter.service;

import com.example.NewsLetter.Dao.impl.UserDao;
import com.example.NewsLetter.entities.User;
import com.example.NewsLetter.input.InputRequest;
import com.example.NewsLetter.input.ResponseOutput;
import java.util.List;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
  public ResponseOutput addUser(final InputRequest inputRequest) {
    UserDao userDao = UserDao.getInstance();
    User user = new User();
    user.setId(UUID.randomUUID());
    user.setName(inputRequest.getName());
    user.setEmail(inputRequest.getEmail());
    userDao.save(user);
    ResponseOutput responseOutput = new ResponseOutput();
    responseOutput.setId(String.valueOf(user.getId()));
    return responseOutput;
  }
  public List<User> getAllUser(){
    return UserDao.getInstance().getAll();
  }
}
