package com.example.NewsLetter.service;

import com.example.NewsLetter.Dao.impl.NewsLetterDao;
import com.example.NewsLetter.entities.NewsLetter;
import com.example.NewsLetter.input.InputRequest;
import com.example.NewsLetter.input.ResponseOutput;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class NewsLetterService {
  public List<NewsLetter> getNewsLetterByCategories(final InputRequest inputRequest){
    List<String> categoryList=inputRequest.getCategories();
    NewsLetterDao newsLetterDao= NewsLetterDao.getInstance();
    return newsLetterDao.getByCategories(categoryList);
  }

  public void addNewsLetter(final NewsLetter newsLetter){
    NewsLetterDao newsLetterDao= NewsLetterDao.getInstance();
    newsLetterDao.save(newsLetter);
  }
}
