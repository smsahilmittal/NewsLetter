package com.example.NewsLetter.entities;

import java.util.UUID;
import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
public class User {
  private UUID id;
  private String name;
  private String email;


}
