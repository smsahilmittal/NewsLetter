package com.example.NewsLetter.input;

import lombok.Data;

@Data
public class ResponseOutput {
  private String id;
}
