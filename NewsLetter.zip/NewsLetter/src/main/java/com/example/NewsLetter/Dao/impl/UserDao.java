package com.example.NewsLetter.Dao.impl;

import com.example.NewsLetter.Dao.Dao;
import com.example.NewsLetter.entities.User;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.stereotype.Component;

@Component
public class UserDao implements Dao<String, User> {
  private static UserDao userDao;
  private static Map<String, User> userMap;

  private UserDao() {
  }

  public static UserDao getInstance() {
    if (userDao == null) {
      userMap = new HashMap<>();
      userDao = new UserDao();
    }
    return userDao;
  }

  @Override
  public List<User> getAll() {
    System.out.println(userMap.size());
    return userMap.values().stream().collect(Collectors.toList());
  }

  @Override
  public Optional<User> getById(String key) {
    return Optional.ofNullable(userMap.get(key));
  }

  @Override
  public void save(User entity) {
    userMap.put(String.valueOf(entity.getId()), entity);
  }
}
