package com.example.NewsLetter.Dao.impl;

import com.example.NewsLetter.Dao.Dao;
import com.example.NewsLetter.entities.NewsLetter;
import com.example.NewsLetter.entities.User;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;
import org.springframework.stereotype.Component;

@Component
public class NewsLetterDao implements Dao<String, NewsLetter> {
  private static NewsLetterDao newsLetterDao;
  private static Map<String, NewsLetter> newsLetterMap;

  private NewsLetterDao() {
  }

  public static NewsLetterDao getInstance() {
    if (newsLetterDao == null) {
      newsLetterDao = new NewsLetterDao();
      newsLetterMap = new HashMap<>();
    }
    return newsLetterDao;
  }

  public List<NewsLetter> getByCategories(final List<String> categoryList) {
    List<NewsLetter> newsLetterList = new ArrayList<>();
    for (Map.Entry<String, NewsLetter> entry : newsLetterMap.entrySet()) {
      if (categoryList.contains(entry.getValue().getCategoryName())) {
        newsLetterList.add(entry.getValue());
      }
    }
    return newsLetterList;
  }

  @Override
  public List<NewsLetter> getAll() {
    return newsLetterMap.values().stream().collect(Collectors.toList());
  }

  @Override
  public Optional<NewsLetter> getById(String key) {
    return Optional.ofNullable(newsLetterMap.get(key));
  }

  @Override
  public void save(NewsLetter entity) {
    newsLetterMap.put(entity.getId(), entity);
  }
}
